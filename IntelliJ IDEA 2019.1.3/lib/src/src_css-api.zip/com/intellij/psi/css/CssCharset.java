package com.intellij.psi.css;

import org.jetbrains.annotations.Nullable;

/**
 * @author Eugene.Kudelevsky
 */
public interface CssCharset extends CssAtRule, CssOneLineStatement {
  @Nullable
  String getValue();

  @Nullable
  CssString getValueElement();
}
