package com.intellij.psi.css.descriptor;

import java.util.Comparator;

public enum CssMediaGroup {
  ALL,AURAL,
  CONTINUOUS,PAGED,
  VISUAL,AUDIO,SPEECH,TACTILE,
  GRID,BITMAP,
  INTERACTIVE,STATIC;

  public static final Comparator<? super CssMediaGroup> COMPARATOR = (Comparator<CssMediaGroup>)(o1, o2) -> o2.name().compareTo(o1.name());

}
