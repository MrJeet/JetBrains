package com.intellij.psi.css.descriptor;

public interface CssPseudoClassDescriptor extends CssPseudoSelectorDescriptor {
}
