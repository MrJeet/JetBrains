package com.intellij.sql.psi;

public interface IsImpure {
}