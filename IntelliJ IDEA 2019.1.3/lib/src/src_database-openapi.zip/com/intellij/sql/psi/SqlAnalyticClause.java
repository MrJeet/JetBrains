package com.intellij.sql.psi;

public interface SqlAnalyticClause extends SqlClause {
}
