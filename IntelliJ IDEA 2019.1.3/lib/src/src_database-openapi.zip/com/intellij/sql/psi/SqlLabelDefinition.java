package com.intellij.sql.psi;

public interface SqlLabelDefinition extends SqlLocalDefinition {
}
