package com.intellij.sql.psi;

import com.intellij.database.model.DasRoutine;
import com.intellij.util.containers.JBIterable;
import org.jetbrains.annotations.NotNull;

public interface SqlRoutineDefinition extends SqlDefinition, DasRoutine {
  @NotNull
  JBIterable<? extends SqlElement> getBody();
}
