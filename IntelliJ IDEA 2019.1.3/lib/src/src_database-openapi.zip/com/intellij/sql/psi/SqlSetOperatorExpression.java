package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlSetOperatorExpression extends SqlNAryExpression, SqlResultSetExpression {
}