/*
 * Copyright 2000-2016 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.jam;

import com.intellij.jam.model.util.JamCommonUtil;
import com.intellij.psi.PsiAnnotation;
import com.intellij.psi.PsiAnnotationMemberValue;
import com.intellij.psi.PsiElementRef;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @param <T> Number class to use.
 */
public class JamNumberAttributeElement<T extends Number> extends JamAttributeElement<T> {

  private final Class<? extends T> myClass;

  public JamNumberAttributeElement(String attributeName,
                                   @NotNull PsiElementRef<? extends PsiAnnotation> parent,
                                   Class<? extends T> numberClass) {
    super(attributeName, parent);
    myClass = numberClass;
  }

  public JamNumberAttributeElement(PsiAnnotationMemberValue exactValue, Class<? extends T> numberClass) {
    super(exactValue);
    myClass = numberClass;
  }

  @Nullable
  @Override
  public String getStringValue() {
    final T value = getValue();
    if (value == null) {
      return null;
    }
    return value.toString();
  }

  @Nullable
  @Override
  public T getValue() {
    return JamCommonUtil.getObjectValue(getPsiElement(), myClass);
  }
}
