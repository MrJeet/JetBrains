package com.intellij.javaee.context;

import com.intellij.javaee.application.facet.JavaeeApplicationFacet;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface WebModuleContextProvider {

  @Nullable
  String getContext(@NotNull JavaeeApplicationFacet earFacet, @Nullable String moduleWebUri);
}
