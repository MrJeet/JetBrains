package com.intellij.javaee.customDeployment;

import com.intellij.javaee.deployment.DeploymentSource;
import com.intellij.openapi.project.Project;

public abstract class CustomDeploymentProvider {

  public abstract CustomDeploymentActionHandler createActionHandler(DeploymentSourcesCollection sources, Project project);

  public abstract boolean isSourceProvided(DeploymentSource source);
}
