// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.application.config.hints;

import org.jetbrains.annotations.NotNull;

/**
 * Provide additional value hint references for specific configuration keys.
 */
public interface SpringBootCustomHintReferenceProvider extends SpringBootHintReferenceProvider {
  @NotNull
  String getId();
}
