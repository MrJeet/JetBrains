// Copyright 2000-2017 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.application.metadata;

public final class SpringBootMetadataConstants {

  public static final String PROPERTIES = "properties";
  public static final String GROUPS = "groups";
  public static final String HINTS = "hints";

  public static final String NAME = "name";
  public static final String SOURCE_TYPE = "sourceType";
  public static final String TYPE = "type";
  public static final String DESCRIPTION = "description";
  public static final String DEFAULT_VALUE = "defaultValue";
  public static final String DEPRECATED = "deprecated";
  public static final String DEPRECATION = "deprecation";
  public static final String REPLACEMENT = "replacement";
  public static final String REASON = "reason";
  public static final String LEVEL = "level";

  public static final String SOURCE_METHOD = "sourceMethod";

  public static final String VALUES = "values";
  public static final String PROVIDERS = "providers";

  public static final String VALUE = "value";
  public static final String PARAMETERS = "parameters";
  public static final String TARGET = "target";
  public static final String CONCRETE = "concrete";
  public static final String GROUP = "group";
}
