// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.actions.generate;

import com.intellij.spring.model.xml.beans.SpringBean;
import com.intellij.util.xml.DomElement;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.Nullable;

public class SpringBeanGenerateProvider extends BasicSpringDomGenerateProvider<SpringBean> {

  public SpringBeanGenerateProvider(final String description, @Nullable @NonNls String template) {
    super(description, SpringBean.class, template);
  }

  @Override
  @Nullable
  protected DomElement getElementToNavigate(final SpringBean springBean) {
    return null;
  }
}
