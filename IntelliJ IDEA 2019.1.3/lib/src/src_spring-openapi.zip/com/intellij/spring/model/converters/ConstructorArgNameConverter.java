// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.converters;

import com.intellij.psi.PsiParameter;
import com.intellij.util.xml.ConvertContext;
import com.intellij.util.xml.ResolvingConverter;
import org.jetbrains.annotations.Nullable;

/**
 * @author Yann C&eacute;bron
 */
public abstract class ConstructorArgNameConverter extends ResolvingConverter<PsiParameter> {

  @Override
  public String toString(final @Nullable PsiParameter beanProperty, final ConvertContext context) {
    return null;
  }
}
